<!DOCTYPE html>
<html>

<body>
  <?php

class Tierra { 

 const RADIO_TIERRA = 6371;
 
 // Atributos
 public $nombre;
 public $descripcion;
 public $area;
 public $imagen;

 // Método constructor (opcional)
 public function __construct($nombre = "Tierra", $descripcion = "Nuestro planeta", $imagen = "https://previews.123rf.com/images/tanik/tanik1004/tanik100400081/6877607-sonriendo-tierra-arte-ilustraci%C3%B3n-sobre-un-fondo-blanco.jpg") {
 $this->nombre = $nombre;
 $this->descripcion = $descripcion;
 $this->area = Tierra::calcularArea(); // Calculate area on object creation
$this->imagen = $imagen;
 }
  
  // Método para calcular el área de la Tierra
  public static function calcularArea() {
   return 4 * pi() * pow(self::RADIO_TIERRA, 2);
   }
 
   // Método para mostrar información (opcional)
   public function mostrarInformacion() {
   echo "**Nombre:** " . $this->nombre . "<br>";
   echo "**Descripción:** " . $this->descripcion . "<br>";
   echo "**Área:** " . number_format($this->area, 2) . " kilómetros cuadrados<br>";
   echo "**Imagen:** <a href=\"" . $this->imagen . "\" target=\"_blank\">Ver imagen</a><br>";
   }
  
   }
  

  $tierra = new Tierra(); // Create with default values
  $tierra->mostrarInformacion();
  
   
  ?>
 
</body>
</html>
