<!DOCTYPE html>
<html>
<body>

<?php
class ImagenColoreada {
  public $nombre;
  public $anchoCm;
  public $altoCm;
  public $colores;

  public function __construct(string $nombre, int $anchoPx, int $altoPx, array $colores, float $ppi) {
    $this->nombre = $nombre;
    $this->anchoCm = $anchoPx * $ppi / 2.54;
    $this->altoCm = $altoPx * $ppi / 2.54;
    $this->colores = $colores;
  }

  // ...

  public function mostrarInformacion(): void {
    echo "Nombre: " . $this->nombre . PHP_EOL;
    echo "Ancho: " . $this->anchoCm . "cm" . PHP_EOL;
    echo "Alto: " . $this->altoCm . "cm" . PHP_EOL;
    echo "Colores: " . implode(", ", $this->colores) . PHP_EOL;
  }
}

// Ejemplo de uso
$imagen1 = new ImagenColoreada("Mi foto", 11, 10, ["#87CEEB", "#A05000", "#FFFF00"], 160);

$imagen1->mostrarInformacion();


function obtenerVelocidad(int $tiempo, int $distancia): float {
  return $distancia / $tiempo;
}

$velocidad = obtenerVelocidad(20, 9);

echo "La velocidad es: " . $velocidad . " m/s" . PHP_EOL;
?>

</body>
</html>