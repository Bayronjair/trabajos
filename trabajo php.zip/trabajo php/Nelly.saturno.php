<!DOCTYPE html>
<html>
<body>

<?php

class Saturno{
      //atributo
      var $base;
      var $altura;
      var $constante gravitacional;
      var $velocidad orbital;

     //constructor
     function Saturno($b,$a,$cg,$vo){
     $this->base = $b;
     $this->altura = $a;
     $this->constante gravitacional = $cg;
     $this->velocidad orbital = $vo;
    }

    //metodo
   function Area(){
   $area = ($this->base*$this->altura);
   echo "El area de saturno es: " .$area;
   echo "<br>";
   echo "<br>";
   echo  "El area de saturno es: " .$area;
   }
   
 function Movimiento(){
 $movimiento = ($this->base*this->constante gravitacional);
 echo "El movimiento de saturno es: " .$movimiento;
  echo "<br>";
   echo "<br>";
   echo   "El movimiento de saturno es: " .$movimiento;
 }  
 
 function Tiempo(){
 $tiempo = ($this->distancia*this->velocidad orbital);
 echo "El tiempo de saturno es: " .$tiempo
  echo "<br>";
   echo "<br>";
   echo "El tiempo de saturno es: " .$tiempo  
 
$objeto1 = new saturno();
$objeto1->Area();
$objeto2 = new saturno();
$objeto2->Tiempo();
?> 

</body>
</html>
